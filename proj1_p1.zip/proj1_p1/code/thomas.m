function V = thomas(alpha,beta,gamma,b)
    n=length(alpha);
    m=zeros(1,n);phi=m;
    c=zeros(n,1);v=c;

    phi(1)=alpha(1);
    c(1)=b(1);
    for k=2:n
        m(k)=beta(k)/phi(k-1);
        phi(k)=alpha(k)-m(k)*gamma(k-1);
        c(k)=b(k)-m(k)*c(k-1);
    end
    v(n)= c(n)/phi(n);
    for k=(n-1):-1:1
        v(k)=(c(k)-gamma(k)*v(k+1))/phi(k);
    end
    V = v;
end